const request = require("supertest");
const mongoose = require("mongoose");
const app = require("../index");
const Invoice = require("../modules/Invoice/invoice.model");
const Payment = require("../modules/Payment/payment.model");
const PerformedService = require("../modules/performedService/performedService.model");
const Visit = require("../modules/Visit/visit.model");
const Appointment = require("../modules/Appointment/appointment.model");
const {
  createTestUser,
  createTestDoctor,
  createTestPatient,
  getFutureAppointmentDate,
} = require("./testHelper");

describe("Invoices and payments API", () => {
  let receptionist;
  let patient;
  let doctor;
  let visit;

  beforeEach(async () => {
    receptionist = await createTestUser({ role: "receptionist" });
    patient = await createTestPatient(receptionist.user);
    ({ doctor } = await createTestDoctor(receptionist.user));
    const appointment = await Appointment.create({
      patient: patient._id,
      doctor: doctor._id,
      appointmentDate: getFutureAppointmentDate(),
      duration: 30,
      status: "confirmed",
      createdBy: receptionist.user._id,
    });
    visit = await Visit.create({
      appointment: appointment._id,
      patient: patient._id,
      doctor: doctor._id,
      chiefComplaint: "Routine examination",
      createdBy: receptionist.user._id,
    });
    await PerformedService.create([
      {
        visit: visit._id,
        patient: patient._id,
        doctor: doctor._id,
        service: new mongoose.Types.ObjectId(),
        serviceName: "Consultation",
        serviceCode: "CONSULT",
        price: 80,
        quantity: 2,
        discount: 10,
        createdBy: receptionist.user._id,
      },
      {
        visit: visit._id,
        patient: patient._id,
        doctor: doctor._id,
        service: new mongoose.Types.ObjectId(),
        serviceName: "Lab test",
        serviceCode: "LAB-1",
        price: 25,
        quantity: 1,
        discount: 0,
        createdBy: receptionist.user._id,
      },
    ]);
  });

  test("creates an invoice with calculated line items, discounts, tax, and total", async () => {
    const response = await request(app)
      .post("/api/invoices")
      .set("Authorization", receptionist.authHeader)
      .send({
        visit: visit._id.toString(),
        discount: 5,
        tax: 7,
      });

    expect(response.status).toBe(201);
    expect(response.body.data.items).toHaveLength(2);
    expect(response.body.data.subtotal).toBe(175);
    expect(response.body.data.discount).toBe(5);
    expect(response.body.data.tax).toBe(7);
    expect(response.body.data.total).toBe(177);
    expect(response.body.data.remainingAmount).toBe(177);
    expect(response.body.data.status).toBe("unpaid");
  });

  test("updates invoice paid balance and status as payments are recorded", async () => {
    const invoice = await Invoice.create({
      invoiceNumber: "INV-TEST-000001",
      visit: visit._id,
      patient: patient._id,
      doctor: doctor._id,
      items: [
        {
          performedService: new mongoose.Types.ObjectId(),
          serviceName: "Consultation",
          serviceCode: "CONSULT",
          unitPrice: 100,
          quantity: 1,
          discount: 0,
          total: 100,
        },
      ],
      subtotal: 100,
      discount: 0,
      tax: 0,
      total: 100,
      paidAmount: 0,
      remainingAmount: 100,
      status: "unpaid",
      createdBy: receptionist.user._id,
    });

    const partialPaymentResponse = await request(app)
      .post("/api/payments")
      .set("Authorization", receptionist.authHeader)
      .send({
        invoice: invoice._id.toString(),
        amount: 40,
        method: "cash",
      });

    expect(partialPaymentResponse.status).toBe(201);
    expect(partialPaymentResponse.body.data.amount).toBe(40);

    let updatedInvoice = await Invoice.findById(invoice._id);
    expect(updatedInvoice.paidAmount).toBe(40);
    expect(updatedInvoice.remainingAmount).toBe(60);
    expect(updatedInvoice.status).toBe("partially_paid");

    const finalPaymentResponse = await request(app)
      .post("/api/payments")
      .set("Authorization", receptionist.authHeader)
      .send({
        invoice: invoice._id.toString(),
        amount: 60,
        method: "cash",
      });

    expect(finalPaymentResponse.status).toBe(201);
    updatedInvoice = await Invoice.findById(invoice._id);
    expect(updatedInvoice.paidAmount).toBe(100);
    expect(updatedInvoice.remainingAmount).toBe(0);
    expect(updatedInvoice.status).toBe("paid");
    expect(await Payment.countDocuments({ invoice: invoice._id })).toBe(2);
  });

  test("rejects invoice creation when the visit has no performed services", async () => {
    await PerformedService.deleteMany({ visit: visit._id });

    const response = await request(app)
      .post("/api/invoices")
      .set("Authorization", receptionist.authHeader)
      .send({ visit: visit._id.toString() });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("NO_PERFORMED_SERVICES");
  });
});
