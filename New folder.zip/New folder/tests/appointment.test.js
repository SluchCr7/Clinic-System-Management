const request = require("supertest");
const app = require("../index");
const Appointment = require("../modules/Appointment/appointment.model");
const {
  createTestUser,
  createTestDoctor,
  createTestPatient,
  createTestSchedule,
  getFutureAppointmentDate,
} = require("./testHelper");

describe("Appointments API", () => {
  let receptionist;
  let doctor;
  let patient;
  let appointmentDate;

  beforeEach(async () => {
    receptionist = await createTestUser({ role: "receptionist" });
    patient = await createTestPatient(receptionist.user);
    ({ doctor } = await createTestDoctor(receptionist.user));
    appointmentDate = getFutureAppointmentDate();
    await createTestSchedule(doctor, receptionist.user, appointmentDate);
  });

  const createAppointmentPayload = () => ({
    patient: patient._id.toString(),
    doctor: doctor._id.toString(),
    appointmentDate: appointmentDate.toISOString(),
    duration: 30,
    reason: "Routine consultation",
  });

  test("creates an appointment with a scheduled status", async () => {
    const response = await request(app)
      .post("/api/appointments")
      .set("Authorization", receptionist.authHeader)
      .send(createAppointmentPayload());

    expect(response.status).toBe(201);
    expect(response.body.data.patient).toBe(patient._id.toString());
    expect(response.body.data.doctor).toBe(doctor._id.toString());
    expect(response.body.data.status).toBe("scheduled");
    expect(response.body.data.reminderSent).toBe(false);
  });

  test("rejects an overlapping appointment for the same doctor", async () => {
    await Appointment.create({
      ...createAppointmentPayload(),
      appointmentDate,
      createdBy: receptionist.user._id,
    });

    const response = await request(app)
      .post("/api/appointments")
      .set("Authorization", receptionist.authHeader)
      .send(createAppointmentPayload());

    expect(response.status).toBe(409);
    expect(response.body.code).toBe("APPOINTMENT_CONFLICT");
  });

  test("rejects a booking when required fields are missing", async () => {
    const response = await request(app)
      .post("/api/appointments")
      .set("Authorization", receptionist.authHeader)
      .send({ patient: patient._id.toString() });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("VALIDATION_ERROR");
  });

  test("updates appointment status and rejects invalid transitions", async () => {
    const created = await Appointment.create({
      ...createAppointmentPayload(),
      appointmentDate,
      createdBy: receptionist.user._id,
    });

    const updateResponse = await request(app)
      .patch(`/api/appointments/${created._id}`)
      .set("Authorization", receptionist.authHeader)
      .send({ status: "confirmed" });

    expect(updateResponse.status).toBe(200);
    expect(updateResponse.body.data.status).toBe("confirmed");

    await Appointment.updateOne(
      { _id: created._id },
      { $set: { status: "completed" } }
    );
    const invalidTransitionResponse = await request(app)
      .patch(`/api/appointments/${created._id}`)
      .set("Authorization", receptionist.authHeader)
      .send({ status: "scheduled" });

    expect(invalidTransitionResponse.status).toBe(400);
    expect(invalidTransitionResponse.body.code).toBe(
      "INVALID_STATUS_TRANSITION"
    );
  });

  test("resets the reminder flag when an appointment is rescheduled", async () => {
    const created = await Appointment.create({
      ...createAppointmentPayload(),
      appointmentDate,
      reminderSent: true,
      createdBy: receptionist.user._id,
    });
    const rescheduledDate = getFutureAppointmentDate(4);
    await createTestSchedule(doctor, receptionist.user, rescheduledDate);

    const response = await request(app)
      .patch(`/api/appointments/${created._id}`)
      .set("Authorization", receptionist.authHeader)
      .send({ appointmentDate: rescheduledDate.toISOString() });

    expect(response.status).toBe(200);
    expect(response.body.data.reminderSent).toBe(false);
  });
});
