const request = require("supertest");
const app = require("../index");
const Patient = require("../modules/Patient/patient.model");
const { createTestUser } = require("./testHelper");

describe("Patients API", () => {
  let receptionist;

  beforeEach(async () => {
    receptionist = await createTestUser({ role: "receptionist" });
  });

  const newPatient = () => ({
    firstName: "Jordan",
    lastName: "Patient",
    dateOfBirth: "1985-07-13",
    gender: "male",
    phone: "555-0150",
    email: "jordan.patient@example.com",
    bloodType: "O+",
    allergies: ["Penicillin"],
    chronicDiseases: ["Asthma"],
  });

  test("creates and retrieves a patient profile", async () => {
    const createResponse = await request(app)
      .post("/api/patients")
      .set("Authorization", receptionist.authHeader)
      .send(newPatient());

    expect(createResponse.status).toBe(201);
    expect(createResponse.body.data.firstName).toBe("Jordan");
    expect(createResponse.body.data.createdBy).toBe(
      receptionist.user._id.toString()
    );

    const detailResponse = await request(app)
      .get(`/api/patients/${createResponse.body.data._id}`)
      .set("Authorization", receptionist.authHeader);

    expect(detailResponse.status).toBe(200);
    expect(detailResponse.body.data.email).toBe(
      "jordan.patient@example.com"
    );
    expect(detailResponse.body.data.allergies).toContain("Penicillin");
  });

  test("updates a patient's medical records", async () => {
    const patient = await Patient.create({
      ...newPatient(),
      createdBy: receptionist.user._id,
    });

    const response = await request(app)
      .patch(`/api/patients/${patient._id}`)
      .set("Authorization", receptionist.authHeader)
      .send({
        bloodType: "A+",
        allergies: ["Penicillin", "Latex"],
        chronicDiseases: ["Asthma", "Diabetes"],
      });

    expect(response.status).toBe(200);
    expect(response.body.data.bloodType).toBe("A+");
    expect(response.body.data.allergies).toEqual(["Penicillin", "Latex"]);
    expect(response.body.data.chronicDiseases).toContain("Diabetes");
  });

  test("rejects invalid patient data", async () => {
    const response = await request(app)
      .post("/api/patients")
      .set("Authorization", receptionist.authHeader)
      .send({
        ...newPatient(),
        dateOfBirth: "2099-01-01",
        gender: "unknown",
      });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("VALIDATION_ERROR");
  });
});
